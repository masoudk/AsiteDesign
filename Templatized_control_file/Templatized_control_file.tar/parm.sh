python2.7 -m molfile_to_params --keep-names --clobber -n ${1%.*} -c  $1
